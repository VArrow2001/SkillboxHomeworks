# -*- coding: utf-8 -*-


def function1():
    print('Я function1 из package_1.module_1')
