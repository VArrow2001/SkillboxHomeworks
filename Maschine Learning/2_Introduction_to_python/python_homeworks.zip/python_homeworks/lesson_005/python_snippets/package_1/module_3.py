# -*- coding: utf-8 -*-

from .module_1 import function1


def function4():
    print('Я function4 из package_1.module_3 вызываю function1')
    function1()
