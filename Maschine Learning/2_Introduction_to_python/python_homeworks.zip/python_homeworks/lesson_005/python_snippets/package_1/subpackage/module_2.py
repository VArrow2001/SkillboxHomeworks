# -*- coding: utf-8 -*-


def function2():
    print('Я function2 из package_1.subpackage.module_2')

