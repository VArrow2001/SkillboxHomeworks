# -*- coding: utf-8 -*-

from ..module_1 import function1


def function5():
    print('Я function5 из package_1.subpackage.module_4 вызываю function1')
    function1()
