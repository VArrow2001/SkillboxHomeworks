# -*- coding: utf-8 -*-


def function3():
    print('Я function3 из package_1/__init__.py')
