# -*- coding: utf-8 -*-


def cos(alpha):
    print('Тут должно быть вычисление косинуса', alpha)
