# -*- coding: utf-8 -*-

folks = ["Яна", "Алёна", ]
